# Web IM

[中文文档](./README_ZH.md)

This sample is about using long polling and WebSocket to build a web-based chat room based on beego.

- [Documentation](http://beego.me/docs/examples/chat.md)
